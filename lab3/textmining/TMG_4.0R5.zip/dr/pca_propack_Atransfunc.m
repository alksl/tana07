function y=pca_propack_Atransfunc(x)
% PCA_PROPACK_ATRANSFUNC - Auxiliary function used in PCA_PROPACK.
%
% Copyright 2007 Dimitrios Zeimpekis, Efstratios Gallopoulos

error(nargchk(1, 1, nargin));
y=pca_propack_Atransfunc_p(x);